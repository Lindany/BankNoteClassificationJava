package bankNotesApplicationPackage;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import java.awt.BorderLayout;
import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.border.TitledBorder;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Point3;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.awt.Color;

import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import org.opencv.core.MatOfPoint;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Moments;

import javax.swing.SpringLayout;
import java.awt.Image;
import java.awt.image.DataBufferByte;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import static java.lang.Math.atan2;
import static java.lang.Math.max;
import java.awt.SystemColor;
import javax.swing.ButtonGroup;

public class BankNoteRecognitionApp {

	private JFrame frmLindaniRicardoMabaso;
	
	final static JFileChooser fileChooser = new JFileChooser();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BankNoteRecognitionApp window = new BankNoteRecognitionApp();
					window.frmLindaniRicardoMabaso.setVisible(true);
					window.frmLindaniRicardoMabaso.setLocationRelativeTo(null);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	static String mainPath="";
	static BankNoteRecognitionApp app_instance = new BankNoteRecognitionApp();
	
	public  BufferedImage Mat2BufferedImage(Mat m){
		// Fastest code
		// output can be assigned either to a BufferedImage or to an Image

		int type = BufferedImage.TYPE_BYTE_GRAY;
		if ( m.channels() > 1 ) {
		    type = BufferedImage.TYPE_3BYTE_BGR;
		}
		int bufferSize = m.channels()*m.cols()*m.rows();
		byte [] b = new byte[bufferSize];
		m.get(0,0,b); // get all the pixels
		BufferedImage image = new BufferedImage(m.cols(),m.rows(), type);
		final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		System.arraycopy(b, 0, targetPixels, 0, b.length);  
		return image;
		}
	
	public static void setPath(String p)
	{
	mainPath=p;	
	}
	
	public String getPath()
	{
		return mainPath;
	}
	
	
	public static File read(String picName)
	{
	try {
		
		System .loadLibrary( Core.NATIVE_LIBRARY_NAME );
		File input = new File(picName);
		
		return input;
	}
	catch (Exception e) {
		 System .out.println("Error: " + e.getMessage());		 
	 }
		return null;
	}
	

	public BufferedImage displayImage;
	/**
	 * Create the frame.
	 */
	
	static boolean mainFlag=false;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	static void setFlag(boolean flag)
	{
		mainFlag=flag;
	}
	
        public void rotate(Mat src, double angle, Mat dst){
            int len = java.lang.Math.max(src.cols(), src.rows());
            Point pt=  new Point(len/2, len/2);
            Mat r = Imgproc.getRotationMatrix2D(pt, angle, 1.0);
            Imgproc.warpAffine(src, dst, r, new Size(len, len));
        }
        
        public Point3 findOrientation(Mat src){
            Moments m = Imgproc.moments(src, true);
            double cen_x = m.m10 / m.m00;
            double cen_y = m.m01 / m.m00;
            double m_11 = 2 * m.m11 - m.m00 * (cen_x * cen_x + cen_y * cen_y);// m.mu11/m.m00;    
            double m_02 = m.m02 - m.m00 * cen_y * cen_y;// m.mu02/m.m00;
            double m_20 = m.m20 - m.m00 * cen_x * cen_x;//m.mu20/m.m00;    
            double theta = m_20 == m_02 ? 0 : atan2(m_11, m_20 - m_02) / 2.0;
            return new Point3(cen_x,cen_y,theta);
        }
        

	/**
	 * Create the application.
	 */
	public BankNoteRecognitionApp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLindaniRicardoMabaso = new JFrame();
		frmLindaniRicardoMabaso.setTitle("Lindani Ricardo Mabaso (215016957)");
		frmLindaniRicardoMabaso.setLocationRelativeTo(null);
		frmLindaniRicardoMabaso.getContentPane().setBackground(UIManager.getColor("InternalFrame.inactiveTitleGradient"));
		frmLindaniRicardoMabaso.setBounds(100, 100, 649, 590);
		frmLindaniRicardoMabaso.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLindaniRicardoMabaso.getContentPane().setLayout(null);
		
		File f = new File("src\\resources_TestingSet\\New100back.jpg");
		fileChooser.setCurrentDirectory(f);
		fileChooser.setSelectedFile(f);
		
		JLabel labelImage = new JLabel("");
		labelImage.setBounds(22, 109, 297, 206);
		frmLindaniRicardoMabaso.getContentPane().add(labelImage);
		
		JButton btnOpenImage = new JButton("Open Image");
		btnOpenImage.addActionListener(new ActionListener() {
			String path="";
			
			public void actionPerformed(ActionEvent arg0) {
				//setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				if (fileChooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) 
				{
					System.out.println("NULL");
				}
			File test;
				String Fname="";
				String Fpath=fileChooser.getSelectedFile().getAbsolutePath();
				Fname=fileChooser.getSelectedFile().getName();
				path = fileChooser.getSelectedFile().getAbsolutePath();//correct
			setPath(path);
				
			   try {					
					displayImage = ImageIO.read(read(path));
				
					labelImage.setIcon(new ImageIcon(displayImage.getScaledInstance(366, 199, Image.SCALE_DEFAULT)));
					//setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
					
				} catch (IOException e1) {
				
					e1.printStackTrace();
				}	
			}
			
		});
		btnOpenImage.setBounds(112, 63, 111, 25);
		frmLindaniRicardoMabaso.getContentPane().add(btnOpenImage);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBounds(12, 101, 315, 223);
		frmLindaniRicardoMabaso.getContentPane().add(panel);
		
		JLabel lblResults = new JLabel("");
		lblResults.setForeground(Color.RED);
		lblResults.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblResults.setBounds(12, 77, 254, 41);
		
		JLabel lblBankNoteRecognition = new JLabel("Bank Note Recognition Application");
		lblBankNoteRecognition.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 20));
		lblBankNoteRecognition.setBounds(130, 13, 348, 27);
		frmLindaniRicardoMabaso.getContentPane().add(lblBankNoteRecognition);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Spatial Filtering", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(350, 53, 258, 84);
		frmLindaniRicardoMabaso.getContentPane().add(panel_1);
		
		JRadioButton rdbtnMedia = new JRadioButton("Median");
		buttonGroup.add(rdbtnMedia);
		
		JRadioButton rdbtnWeightedAverage = new JRadioButton("Weighted Average");
		buttonGroup.add(rdbtnWeightedAverage);
		
		JRadioButton rdbtnGaussian = new JRadioButton("Gaussian");
		buttonGroup.add(rdbtnGaussian);
		rdbtnGaussian.setVerticalAlignment(SwingConstants.TOP);
		
		JRadioButton rdbtnBilateral = new JRadioButton("Bilateral");
		buttonGroup.add(rdbtnBilateral);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(12)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnGaussian)
						.addComponent(rdbtnMedia))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnBilateral)
						.addComponent(rdbtnWeightedAverage)))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(5)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnWeightedAverage)
						.addComponent(rdbtnMedia))
					.addGap(5)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnBilateral)
						.addComponent(rdbtnGaussian)))
		);
		panel_1.setLayout(gl_panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Morphology", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_2.setBounds(350, 150, 258, 84);
		frmLindaniRicardoMabaso.getContentPane().add(panel_2);
		
		JRadioButton rdbtnOpening = new JRadioButton("Opening");
		buttonGroup.add(rdbtnOpening);
		
		JRadioButton rdbtnClosing = new JRadioButton("Closing");
		buttonGroup.add(rdbtnClosing);
		
		JRadioButton rdbtnDilation = new JRadioButton("Dilation");
		buttonGroup.add(rdbtnDilation);
		rdbtnDilation.setVerticalAlignment(SwingConstants.TOP);
		
		JRadioButton rdbtnErosion = new JRadioButton("Erosion");
		buttonGroup.add(rdbtnErosion);
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(10)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnOpening)
						.addComponent(rdbtnClosing))
					.addGap(29)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnErosion)
						.addComponent(rdbtnDilation))
					.addGap(25))
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(5)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnOpening)
						.addComponent(rdbtnDilation))
					.addGap(5)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnClosing)
						.addComponent(rdbtnErosion)))
		);
		panel_2.setLayout(gl_panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Segmentation", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_3.setBounds(350, 258, 258, 84);
		frmLindaniRicardoMabaso.getContentPane().add(panel_3);
		
		JRadioButton rdbtnPrewitt = new JRadioButton("Prewitt");
		buttonGroup.add(rdbtnPrewitt);
		
		JRadioButton rdbtnSobel = new JRadioButton("Sobel");
		buttonGroup.add(rdbtnSobel);
		
		JRadioButton radioButton_6 = new JRadioButton("Gaussian");
		buttonGroup.add(radioButton_6);
		radioButton_6.setVerticalAlignment(SwingConstants.TOP);
		
		JRadioButton rdbtnRobinson = new JRadioButton("Lapacian");
		buttonGroup.add(rdbtnRobinson);
		GroupLayout gl_panel_3 = new GroupLayout(panel_3);
		gl_panel_3.setHorizontalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addGap(13)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel_3.createSequentialGroup()
							.addComponent(rdbtnPrewitt)
							.addGap(32)
							.addComponent(radioButton_6))
						.addGroup(gl_panel_3.createSequentialGroup()
							.addComponent(rdbtnSobel)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(rdbtnRobinson)))
					.addGap(21))
		);
		gl_panel_3.setVerticalGroup(
			gl_panel_3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_3.createSequentialGroup()
					.addGap(5)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnPrewitt)
						.addComponent(radioButton_6))
					.addGap(5)
					.addGroup(gl_panel_3.createParallelGroup(Alignment.BASELINE)
						.addComponent(rdbtnSobel)
						.addComponent(rdbtnRobinson)))
		);
		panel_3.setLayout(gl_panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Classify An Image", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_4.setBounds(330, 381, 278, 148);
		frmLindaniRicardoMabaso.getContentPane().add(panel_4);
		panel_4.setLayout(null);
		
		JButton btnClassify = new JButton("Classify");
		btnClassify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GrayScale gs = new GrayScale();

				try {
					Image j = gs.greyImage(displayImage);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				Convolution cv=new Convolution();
				cv.conv();
				Sharpen s=new Sharpen();
		         s.sharp(); 
				
		      
				//OLD 10 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat source = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld10Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fin = new Mat(source.rows(),source.cols(),source.type());
				Imgproc.equalizeHist(source, fin);
				java.util.List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
				Imgproc.findContours(source, contours, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mom= new Moments();
				mom=Imgproc.moments(contours.get(0),true);
				Mat oldTenFrontHu =new Mat();
				Imgproc.HuMoments(mom, oldTenFrontHu);
				
				//OLD 10 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sourcetb = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld10Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fintb = new Mat(sourcetb.rows(),sourcetb.cols(),sourcetb.type());
				Imgproc.equalizeHist(sourcetb, fintb);
				java.util.List<MatOfPoint> contourstb = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sourcetb, contourstb, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments momtb= new Moments();
				momtb=Imgproc.moments(contourstb.get(0),true);
				Mat oldTenBackHu =new Mat();
				Imgproc.HuMoments(momtb, oldTenBackHu);
				
				//NEW 10 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sourcenewten = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew10Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat finnew10 = new Mat(sourcenewten.rows(),sourcenewten.cols(),sourcenewten.type());
				Imgproc.equalizeHist(sourcenewten, finnew10);
				java.util.List<MatOfPoint> contoursnew10 = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sourcenewten, contoursnew10, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments momn10= new Moments();
				momn10=Imgproc.moments(contoursnew10.get(0),true);
				Mat newTenFrontHu =new Mat();
				Imgproc.HuMoments(momn10, newTenFrontHu);
				
				//NEW 10 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn10b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew10Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn10b = new Mat(sn10b.rows(),sn10b.cols(),sn10b.type());
				Imgproc.equalizeHist(sn10b, fn10b);
				java.util.List<MatOfPoint> cn10b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn10b, cn10b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn10b= new Moments();
				mn10b=Imgproc.moments(cn10b.get(0),true);
				Mat newTenBackHu =new Mat();
				Imgproc.HuMoments(mn10b, newTenBackHu);
				
				//OLD 20 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so20f = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld20Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f020f = new Mat(so20f.rows(),so20f.cols(),so20f.type());
				Imgproc.equalizeHist(so20f, f020f);
				java.util.List<MatOfPoint> co20f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so20f, co20f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo20f= new Moments();
				mo20f=Imgproc.moments(co20f.get(0),true);
				Mat oldTwentyFrontHu =new Mat();
				Imgproc.HuMoments(mo20f, oldTwentyFrontHu);
				
				//OLD 20 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so20b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld20Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f020b = new Mat(so20b.rows(),so20b.cols(),so20b.type());
				Imgproc.equalizeHist(so20b, f020b);
				java.util.List<MatOfPoint> co20b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so20b, co20b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo20b= new Moments();
				mo20b=Imgproc.moments(co20f.get(0),true);
				Mat oldTwentyBackHu =new Mat();
				Imgproc.HuMoments(mo20b, oldTwentyBackHu);
				
				//NEW 20 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn20f = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew20Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn20f = new Mat(sn20f.rows(),sn20f.cols(),sn20f.type());
				Imgproc.equalizeHist(sn20f, fn20f);
				java.util.List<MatOfPoint> cn20f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn20f, cn20f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn20f= new Moments();
				mn20f=Imgproc.moments(cn20f.get(0),true);
				Mat newTwentyFrontHu =new Mat();
				Imgproc.HuMoments(mn20f, newTwentyFrontHu);
				
				//NEW 20 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn20b =  Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew20Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn20b = new Mat(sn20b.rows(),sn20b.cols(),sn20b.type());
				Imgproc.equalizeHist(sn20b, fn20b);
				java.util.List<MatOfPoint> cn20b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn20b, cn20b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn20b = new Moments();
				mn20b=Imgproc.moments(cn20b.get(0),true);
				Mat newTwentyBackHu =new Mat();
				Imgproc.HuMoments(mn20b, newTwentyBackHu);
				
				//OLD 50 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so50f = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld50Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f050f = new Mat(so50f.rows(),so50f.cols(),so50f.type());
				Imgproc.equalizeHist(so50f, f050f);
				java.util.List<MatOfPoint> co50f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so50f, co50f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo50f= new Moments();
				mo50f=Imgproc.moments(co50f.get(0),true);
				Mat oldFiftyFrontHu =new Mat();
				Imgproc.HuMoments(mo50f, oldFiftyFrontHu);
				
				//OLD 50 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so50b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld50Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f050b = new Mat(so50b.rows(),so50b.cols(),so50b.type());
				Imgproc.equalizeHist(so50b, f050b);
				java.util.List<MatOfPoint> co50b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so50b, co50b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo50b= new Moments();
				mo50b=Imgproc.moments(co50b.get(0),true);
				Mat oldFiftyBackHu =new Mat();
				Imgproc.HuMoments(mo50b, oldFiftyBackHu);
				
				//NEW 50 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn50f = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew50Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn50f = new Mat(sn50f.rows(),sn50f.cols(),sn50f.type());
				Imgproc.equalizeHist(sn50f, fn50f);
				java.util.List<MatOfPoint> cn50f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn50f, cn50f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn50f= new Moments();
				mn50f=Imgproc.moments(cn50f.get(0),true);
				Mat newFiftyFrontHu =new Mat();
				Imgproc.HuMoments(mn50f, newFiftyFrontHu);
				
				//NEW 50 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn50b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew50Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn50b = new Mat(sn50b.rows(),sn50b.cols(),sn50b.type());
				Imgproc.equalizeHist(sn50b, fn50b);
				java.util.List<MatOfPoint> cn50b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn50b, cn50b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn50b= new Moments();
				mn50b=Imgproc.moments(cn50b.get(0),true);
				Mat newFiftyBackHu =new Mat();
				Imgproc.HuMoments(mn50b, newFiftyBackHu);
				
				//OLD 100 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so100f = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld100Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f0100f = new Mat(so100f.rows(),so100f.cols(),so100f.type());
				Imgproc.equalizeHist(so100f, f0100f);
				java.util.List<MatOfPoint> co100f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so100f, co100f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo100f= new Moments();
				mo100f=Imgproc.moments(co100f.get(0),true);
				Mat oldOneHFrontHu =new Mat();
				Imgproc.HuMoments(mo100f, oldOneHFrontHu);
				
				//OLD 100 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so100b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld100Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f0100b = new Mat(so100b.rows(),so100b.cols(),so100b.type());
				Imgproc.equalizeHist(so100b, f0100b);
				java.util.List<MatOfPoint> co100b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so100b, co100b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo100b = new Moments();
				mo100b=Imgproc.moments(co100b.get(0),true);
				Mat oldOneHBackHu =new Mat();
				Imgproc.HuMoments(mo100b, oldOneHBackHu);
				
				//NEW 100 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn100f = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew100Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn100f = new Mat(sn100f.rows(),sn100f.cols(),sn100f.type());
				Imgproc.equalizeHist(sn100f, fn100f);
				java.util.List<MatOfPoint> cn100f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn100f, cn100f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn100f= new Moments();
				mn100f=Imgproc.moments(cn100f.get(0),true);
				Mat newOneHFrontHu =new Mat();
				Imgproc.HuMoments(mn100f, newOneHFrontHu);
				
				//NEW 100 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn100b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew100Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn100b = new Mat(sn100b.rows(),sn100b.cols(),sn100b.type());
				Imgproc.equalizeHist(sn100b, fn100b);
				java.util.List<MatOfPoint> cn100b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn100b, cn100b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn100b= new Moments();
				mn100b=Imgproc.moments(cn100b.get(0),true);
				Mat newOneHBackHu =new Mat();
				Imgproc.HuMoments(mn100b, newOneHBackHu);
				
				//OLD 200 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so200f = Imgcodecs.imread("src/resources_ImgThreshold/hresholdOld200Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f0200f = new Mat(so200f.rows(),so200f.cols(),so200f.type());
				Imgproc.equalizeHist(so200f, f0200f);
				java.util.List<MatOfPoint> co200f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so200f, co200f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo200f= new Moments();
				mo200f=Imgproc.moments(co100f.get(0),true);
				Mat oldTwoHFrontHu =new Mat();
				Imgproc.HuMoments(mo200f, oldTwoHFrontHu);
				
				//OLD 200 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat so200b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdOld200Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat f0200b = new Mat(so200b.rows(),so200b.cols(),so200b.type());
				Imgproc.equalizeHist(so200b, f0200b);
				java.util.List<MatOfPoint> co200b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(so200b, co200b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mo200b = new Moments();
				mo200b=Imgproc.moments(co200b.get(0),true);
				Mat oldTwoHBackHu =new Mat();
				Imgproc.HuMoments(mo200b, oldTwoHBackHu);
				
				//NEW 200 FRONT
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn200f = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew200Front.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn200f = new Mat(sn200f.rows(),sn200f.cols(),sn200f.type());
				Imgproc.equalizeHist(sn200f, fn200f);
				java.util.List<MatOfPoint> cn200f = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn200f, cn200f, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn200f= new Moments();
				mn200f=Imgproc.moments(cn200f.get(0),true);
				Mat newTwoHFrontHu =new Mat();
				Imgproc.HuMoments(mn200f, newTwoHFrontHu);
				
				//NEW 200 BACK
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
				Mat sn200b = Imgcodecs.imread("src/resources_ImgThreshold/ThresholdNew200Back.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat fn200b = new Mat(sn200b.rows(),sn200b.cols(),sn200b.type());
				Imgproc.equalizeHist(sn200b, fn200b);
				java.util.List<MatOfPoint> cn200b = new ArrayList<MatOfPoint>();
				Imgproc.findContours(sn200b, cn200b, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mn200b= new Moments();
				mn200b=Imgproc.moments(cn200b.get(0),true);
				Mat newTwoHBackHu =new Mat();
				Imgproc.HuMoments(mn200b, newTwoHBackHu);
				
				//Test Image
				Thresholding he = new Thresholding();
		         Mat heim = he.thresh();
		         Image x11 = app_instance.Mat2BufferedImage(heim);
				
				System .loadLibrary( Core.NATIVE_LIBRARY_NAME );			
			    Mat st = Imgcodecs.imread("src/resources_output/Threshold.jpg", Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);
				Mat ft = new Mat(st.rows(),st.cols(),st.type());
				Imgproc.equalizeHist(st, ft);
				java.util.List<MatOfPoint> ct = new ArrayList<MatOfPoint>();
				Imgproc.findContours(st, ct, new Mat(), Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
				Moments mt= new Moments();
				mt=Imgproc.moments(ct.get(0),true);
				Mat HuTest =new Mat();
				Imgproc.HuMoments(mt, HuTest);
					
				for(int k=0;k<7;k++){
					
					if(HuTest.get(k, 0)[0]==oldTenFrontHu.get(k, 0)[0]){
						lblResults.setText("OLD TEN RAND");
						System.out.println("AN OLD TEN RAND");
					}
					else if(HuTest.get(k, 0)[0]==oldTenBackHu.get(k, 0)[0]){
						lblResults.setText("OLD TEN RAND");
					System.out.println("OLD TEN RAND");
					}
					else if(HuTest.get(k, 0)[0]==newTenFrontHu.get(k, 0)[0])
						lblResults.setText("NEW TEN RAND");	   
					else if(HuTest.get(k, 0)[0]==newTenBackHu.get(k, 0)[0])
						lblResults.setText("NEW TEN RAND");
					else if(HuTest.get(k, 0)[0]==oldTwentyFrontHu.get(k, 0)[0])
						lblResults.setText("OLD TWENTY RAND");
					else if(HuTest.get(k, 0)[0]==oldTwentyBackHu.get(k, 0)[0])
						lblResults.setText("OLD TWENTY RAND");
					else if(HuTest.get(k, 0)[0]==newTwentyFrontHu.get(k, 0)[0])
						lblResults.setText("NEW TWENTY RAND");
					else if(HuTest.get(k, 0)[0]==newTwentyBackHu.get(k, 0)[0])
						lblResults.setText("NEW TWENTY RAND");
					else if(HuTest.get(k, 0)[0]==oldFiftyFrontHu.get(k, 0)[0])
						lblResults.setText("OLD FIFTY RAND");
					else if(HuTest.get(k, 0)[0]==oldFiftyBackHu.get(k, 0)[0])
						lblResults.setText("OLD FIFTY RAND");
					else if(HuTest.get(k, 0)[0]==newFiftyFrontHu.get(k, 0)[0])
						lblResults.setText("NEW FIFTY RAND");
					else if(HuTest.get(k, 0)[0]==newFiftyBackHu.get(k, 0)[0])
						lblResults.setText("NEW FIFTY RAND");
					else if(HuTest.get(k, 0)[0]==oldOneHFrontHu.get(k, 0)[0])
						lblResults.setText("OLD ONE HUNDRED RAND");
					else if(HuTest.get(k, 0)[0]==oldOneHBackHu.get(k, 0)[0])
						lblResults.setText("OLD ONE HUNDRED RAND");
					else if(HuTest.get(k, 0)[0]==newOneHFrontHu.get(k, 0)[0])
						lblResults.setText("NEW ONE HUNDRED RAND");
					else if(HuTest.get(k, 0)[0]==newOneHBackHu.get(k, 0)[0])
						lblResults.setText("NEW ONE HUNDRED RAND");
					else if(HuTest.get(k, 0)[0]==oldTwoHFrontHu.get(k, 0)[0])
						lblResults.setText("OLD TWO HUNDRED RAND");
					else if(HuTest.get(k, 0)[0]==oldTwoHBackHu.get(k, 0)[0])
						lblResults.setText("OLD TWO HUNDRED RAND");
					else if(HuTest.get(k, 0)[0]==newTwoHFrontHu.get(k, 0)[0])
						lblResults.setText("NEW TWO HUNDRED RAND");
					else if(HuTest.get(k, 0)[0]==newTwoHBackHu.get(k, 0)[0])
						lblResults.setText("NEW TWO HUNDRED RAND");
				
				}
			}
		});
		btnClassify.setBounds(49, 39, 186, 25);
		panel_4.add(btnClassify);
		
		panel_4.add(lblResults);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(12, 337, 306, 192);
		frmLindaniRicardoMabaso.getContentPane().add(panel_5);
		panel_5.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Preprocessing", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JButton btnConvertToGrayscale = new JButton("Convert To Grayscale");
		btnConvertToGrayscale.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Image j = GrayScale.greyImage(displayImage);
					labelImage.setIcon(new ImageIcon(j.getScaledInstance(366, 199, Image.SCALE_DEFAULT)));
					//setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton btnConvolution = new JButton("Convolution");
		btnConvolution.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GrayScale gs = new GrayScale();

				try {
					Image j = gs.greyImage(displayImage);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Convolution con = new Convolution();
		         Mat heim = con.conv();
		         Image x11 = app_instance.Mat2BufferedImage(heim);
		         labelImage.setIcon(new ImageIcon(x11.getScaledInstance(366, 199, Image.SCALE_DEFAULT)));
				 //setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		});
		
		JButton btnHistogramEqualization = new JButton("Histogram Equalization");
		btnHistogramEqualization.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GrayScale gs = new GrayScale();

				try {
					Image j = gs.greyImage(displayImage);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				HistogramEqualisation he = new HistogramEqualisation();
		         Mat heim = he.histogram();
		         Image x11 = app_instance.Mat2BufferedImage(heim);
		         
		         labelImage.setIcon(new ImageIcon(x11.getScaledInstance(366, 199, Image.SCALE_DEFAULT)));
				 //setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			
			}
		});
		
		JButton btnNewButton = new JButton("Laplacian Operator");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GrayScale gs = new GrayScale();

				try {
					Image j = gs.greyImage(displayImage);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Laplacian he = new Laplacian();
		         Mat heim = he.lap();
		         Image x11 = app_instance.Mat2BufferedImage(heim);
		         labelImage.setIcon(new ImageIcon(x11.getScaledInstance(366, 199, Image.SCALE_DEFAULT)));
				 //setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
			
		});
		
		JButton btnNewButton_1 = new JButton("Thresholding");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GrayScale gs = new GrayScale();

				try {
					Image j = gs.greyImage(displayImage);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Thresholding he = new Thresholding();
		         Mat heim = he.thresh();
		         Image x11 = app_instance.Mat2BufferedImage(heim);
		         labelImage.setIcon(new ImageIcon(x11.getScaledInstance(366, 199, Image.SCALE_DEFAULT)));
				 //setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			
			}
		});
		GroupLayout gl_panel_5 = new GroupLayout(panel_5);
		gl_panel_5.setHorizontalGroup(
			gl_panel_5.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel_5.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_5.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnNewButton_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
						.addComponent(btnNewButton, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
						.addComponent(btnHistogramEqualization, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
						.addComponent(btnConvolution, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
						.addComponent(btnConvertToGrayscale, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 262, GroupLayout.PREFERRED_SIZE))
					.addGap(20))
		);
		gl_panel_5.setVerticalGroup(
			gl_panel_5.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_5.createSequentialGroup()
					.addComponent(btnConvertToGrayscale)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnConvolution)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnHistogramEqualization)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnNewButton)
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(btnNewButton_1)
					.addContainerGap())
		);
		panel_5.setLayout(gl_panel_5);
	}
}
