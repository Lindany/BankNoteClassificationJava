package bankNotesApplicationPackage;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class Sharpen {
	public Mat sharp()
	{ 
	    
		String openCVPATH=System.getProperty("user.dir");
		String libPath=System.getProperty("java.library.path");
	
		        System.loadLibrary( Core.NATIVE_LIBRARY_NAME );      
		 	
		       Mat source = Imgcodecs.imread("src/resources_output/histogram.jpg",  Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE); 
	
		Mat destination = new Mat(source.rows(),source.cols(),source.type());         
		Imgproc.GaussianBlur(source, destination, new Size(0,0), 100);    
		
		Core.addWeighted(source, 1.5, destination, -0.75, 0, destination);         

		
		Imgcodecs.imwrite("src/resources_output/sharpenedImage.jpg", destination);
		
		
		return destination;
	} 
}
