package bankNotesApplicationPackage;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class Thresholding {

	public Mat thresh(  )
	{     
		String openCVPATH=System.getProperty("user.dir");
		String libPath=System.getProperty("java.library.path");

        System.loadLibrary( Core.NATIVE_LIBRARY_NAME );      
 		Mat source = Imgcodecs.imread("gray.jpg",  Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE); 
        Mat source1 = Imgcodecs.imread("gray.jpg",  Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE);  
         Mat source11 = Imgcodecs.imread("src/resources_output/gray.jpg",  Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE); 
         Mat destination = new Mat(source11.rows(),source11.cols(),source11.type());
         destination = source11;         
       
         Imgproc.threshold(source11,destination,127,250,Imgproc.THRESH_TOZERO); 
         Imgcodecs.imwrite("src/resources_output/Threshold.jpg", destination);         
         return destination;
	}
}
