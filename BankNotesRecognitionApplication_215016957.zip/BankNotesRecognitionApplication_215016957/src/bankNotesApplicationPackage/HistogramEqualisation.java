package bankNotesApplicationPackage;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class HistogramEqualisation {
	 static int width; 
	   static int height; 
	   static double alpha = 2; 
	   static double beta = 50; 
	   public Mat histogram( ) 
	   { 
	        
		   String openCVPATH=System.getProperty("user.dir");
		   String libPath=System.getProperty("java.library.path");
		   
		           System.loadLibrary( Core.NATIVE_LIBRARY_NAME );      
		    		
		            Mat src = Imgcodecs.imread("src/resources_output/gray.jpg",  Imgcodecs.CV_LOAD_IMAGE_GRAYSCALE); 
	         Mat destination = new  Mat(src.rows(),src.cols(),src.type());
	        
	         Imgproc.equalizeHist(src, destination); 
	         
	         Imgcodecs.imwrite("src/resources_output/histogram.jpg", destination); 
	         return destination;
	   } 
}
