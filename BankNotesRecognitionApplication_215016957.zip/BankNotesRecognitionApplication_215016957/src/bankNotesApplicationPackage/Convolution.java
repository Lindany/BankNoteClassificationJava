package bankNotesApplicationPackage;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class Convolution {
	public Mat conv(){
		int kernel_size = 3;
		
		String openCVPATH = System.getProperty("user.dir");
		String libPATH = System.getProperty("java.library.path");
		
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		Mat srcs = Imgcodecs.imread("src/resources_output/gray.jpg");
		Mat dst = new Mat(srcs.rows(),srcs.cols(),srcs.type());
		Mat kernel = new Mat(kernel_size,kernel_size,CvType.CV_32F){
			{
				put(0,0,0);               
	        	put(0,1,0); 
	        	put(0,0,0);
        		  
	            put(1,0,0);  
	            put(1,1,1);
	            put(1,2,0);
	                            
	            put(2,0,0); 
	            put(2,1,0);    
	            put(2,2,0); 
			}
		};
		Imgproc.filter2D(srcs, dst, -1, kernel);
		//Imgcodecs.imwrite("convolution.jpg",dst);
		Imgcodecs.imwrite("src/resources_output/convolution.jpg", dst);
		return dst;	
	}
}
