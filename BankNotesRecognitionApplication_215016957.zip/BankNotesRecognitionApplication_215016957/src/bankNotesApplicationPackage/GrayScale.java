package bankNotesApplicationPackage;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import java.util.*;

import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;

public class GrayScale {
	
	public static Image greyImage(BufferedImage image) throws IOException
	{
		//Hough hg =new Hough();
		Sharpen s=new Sharpen();
		//SobelEdge sb=new SobelEdge();
		//CannyEgde ed=new CannyEgde();
		HistogramEqualisation hs=new HistogramEqualisation();
		//hs.histogram();
		Mat pro=null;
		Convolution cv=new Convolution();
		cv.conv();
		byte[] data = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        Mat mat = new Mat(image.getHeight(), image.getWidth(), CvType.CV_8UC3);
        mat.put(0, 0, data);

        Mat mat1 = new Mat(image.getHeight(),image.getWidth(),CvType.CV_8UC1);
        Imgproc.cvtColor(mat, mat1, Imgproc.COLOR_RGB2GRAY);
        //applying sharpeningImgproc.COLOR_RGB2GRAY;
        pro=mat1;
        //hg.Hou(mat1);
        //hs.histogram();
        //pro=s.sharp(mat1);
        //pro=ed.edge(mat1);
        //pro=sb.Sobel(mat1);

        //pro=hs.histogram(mat1);
        byte[] data1 = new byte[pro.rows() * pro.cols() * (int)(pro.elemSize())];
        pro.get(0, 0, data1);
        BufferedImage image1 = new BufferedImage(pro.cols(),pro.rows(), BufferedImage.TYPE_BYTE_GRAY);
        image1.getRaster().setDataElements(0, 0, pro.cols(), pro.rows(), data1);

        File output = new File("src/resources_output/gray.jpg");
        ImageIO.write(image1, "jpg", output);
        BankNoteRecognitionApp app_instance = new BankNoteRecognitionApp();
      
        Image im = app_instance.Mat2BufferedImage(mat);
     
        Image k = app_instance.Mat2BufferedImage(pro);
        return k;
	}
}
