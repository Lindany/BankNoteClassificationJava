package bankNotesApplicationPackage;


public class FeatureExtraction {

}
