package bankNotesApplicationPackage;


public class Negative {

}
