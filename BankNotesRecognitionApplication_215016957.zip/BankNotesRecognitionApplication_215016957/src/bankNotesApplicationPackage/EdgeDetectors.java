package bankNotesApplicationPackage;


public class EdgeDetectors {

}
